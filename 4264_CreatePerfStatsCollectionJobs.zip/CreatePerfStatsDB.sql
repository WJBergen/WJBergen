USE [master]
GO
/****** Object:  Database [PerfStats]    Script Date: 04/10/2016 12:16:35 ******/

CREATE DATABASE [PerfStats] ON  PRIMARY 
( NAME = N'PerfStats', FILENAME = N'C:\Data\PerfStats.mdf' , SIZE =3MB , MAXSIZE = UNLIMITED, FILEGROWTH = 512KB )			--To be customized 
 LOG ON 
( NAME = N'PerfStats_log', FILENAME = N'C:\Data\PerfStats_log.ldf' , SIZE = 512KB , MAXSIZE = 2048GB , FILEGROWTH = 512KB)	--To be customized 
GO
ALTER DATABASE [PerfStats] SET COMPATIBILITY_LEVEL = 100			--To be customized 
GO
ALTER DATABASE [PerfStats] SET ANSI_NULL_DEFAULT OFF
GO
ALTER DATABASE [PerfStats] SET ANSI_NULLS OFF
GO
ALTER DATABASE [PerfStats] SET ANSI_PADDING OFF
GO
ALTER DATABASE [PerfStats] SET ANSI_WARNINGS OFF
GO
ALTER DATABASE [PerfStats] SET ARITHABORT OFF
GO
ALTER DATABASE [PerfStats] SET AUTO_CLOSE OFF
GO
ALTER DATABASE [PerfStats] SET AUTO_CREATE_STATISTICS ON
GO
ALTER DATABASE [PerfStats] SET AUTO_SHRINK OFF
GO
ALTER DATABASE [PerfStats] SET AUTO_UPDATE_STATISTICS ON
GO
ALTER DATABASE [PerfStats] SET CURSOR_CLOSE_ON_COMMIT OFF
GO
ALTER DATABASE [PerfStats] SET CURSOR_DEFAULT  GLOBAL
GO
ALTER DATABASE [PerfStats] SET CONCAT_NULL_YIELDS_NULL OFF
GO
ALTER DATABASE [PerfStats] SET NUMERIC_ROUNDABORT OFF
GO
ALTER DATABASE [PerfStats] SET QUOTED_IDENTIFIER OFF
GO
ALTER DATABASE [PerfStats] SET RECURSIVE_TRIGGERS OFF
GO
ALTER DATABASE [PerfStats] SET  DISABLE_BROKER
GO
ALTER DATABASE [PerfStats] SET AUTO_UPDATE_STATISTICS_ASYNC OFF
GO
ALTER DATABASE [PerfStats] SET DATE_CORRELATION_OPTIMIZATION OFF
GO
ALTER DATABASE [PerfStats] SET TRUSTWORTHY OFF
GO
ALTER DATABASE [PerfStats] SET ALLOW_SNAPSHOT_ISOLATION OFF
GO
ALTER DATABASE [PerfStats] SET PARAMETERIZATION SIMPLE
GO
ALTER DATABASE [PerfStats] SET READ_COMMITTED_SNAPSHOT OFF
GO
ALTER DATABASE [PerfStats] SET HONOR_BROKER_PRIORITY OFF
GO
ALTER DATABASE [PerfStats] SET  READ_WRITE
GO
ALTER DATABASE [PerfStats] SET RECOVERY SIMPLE
GO
ALTER DATABASE [PerfStats] SET  MULTI_USER
GO
ALTER DATABASE [PerfStats] SET PAGE_VERIFY CHECKSUM
GO
ALTER DATABASE [PerfStats] SET DB_CHAINING OFF
GO
EXEC sys.sp_db_vardecimal_storage_format N'PerfStats', N'ON'
GO
USE [PerfStats]
GO


/****** Object:  Table [dbo].[WaitStatistics]    Script Date: 04/10/2016 12:16:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[WaitStatistics](
	[RecId] [int] IDENTITY(1,1) NOT NULL,
	[SQLInstanceName] [varchar](200) NOT NULL,
	[Wait_type] [nvarchar](60) NOT NULL,
	[wait_time_s] [decimal](12, 2) NULL,
	[Pct] [decimal](12, 2) NULL,
	[CollectionDateTime] [datetime] NULL
	 CONSTRAINT [PK_WaitStatistics] PRIMARY KEY CLUSTERED 
(
	[RecId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ProcStats]    Script Date: 04/10/2016 12:16:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ProcStats](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[SQLInstanceName] [varchar](200) NOT NULL,
	[HostName] [varchar](200) NULL,
	[DbName] [varchar](200) NULL,
	[QueryTxt] [varchar](max) NULL,
	[TotalWorkerTime_Msec] [int] NULL,
	[TotalElapsedTime_Msec] [int] NULL,
	[TotalLogicalReads] [bigint] NULL,
	[MaxElapsedTime_Msec] [int] NULL,
	[MaxWorkerTime_Msec] [int] NULL,
	[MaxLogicalReads] [bigint] NULL,
	[MinElapsedTime_Msec] [int] NULL,
	[MinWorkerTime_Msec] [int] NULL,
	[MinLogicalReads] [bigint] NULL,
	[ExecutionCount] [int] NULL,
	[SqlHandle] [varbinary](64) NULL,
	[PlanHash] [binary](8) NULL,
	[DateModified] [datetime] NULL,
	[CollectionDateTime] [datetime] NOT NULL
	 CONSTRAINT [PK_ProcStats] PRIMARY KEY CLUSTERED 
(
	[Id] ASC,
	[SQLInstanceName] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[QueryStats]    Script Date: 04/10/2016 12:16:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[QueryStats](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[SQLInstanceName] [varchar](200) NOT NULL,
	[HostName] [varchar](200) NULL,
	[DbName] [varchar](200) NULL,
	[ParentQueryTxt] [varchar](max) NULL,
	[QueryTxt] [varchar](max) NULL,
	[TotalWorkerTime_Msec] [int] NULL,
	[TotalElapsedTime_Msec] [int] NULL,
	[TotalLogicalReads] [bigint] NULL,
	[MaxElapsedTime_Msec] [int] NULL,
	[MaxWorkerTime_Msec] [int] NULL,
	[MaxLogicalReads] [bigint] NULL,
	[MinElapsedTime_Msec] [int] NULL,
	[MinWorkerTime_Msec] [int] NULL,
	[MinLogicalReads] [bigint] NULL,
	[ExecutionCount] [int] NULL,
	[QueryHash] [binary](8) NULL,
	[PlanHash] [binary](8) NULL,
	[SqlHandle] [varbinary](64) NULL,
	[Statement_start_offset] [int] NULL,
	[DateModified] [datetime] NULL,
	[CollectionDateTime] [datetime] NOT NULL
 CONSTRAINT [PK_QueryStats_1] PRIMARY KEY CLUSTERED 
(
	[Id] ASC,
	[SQLInstanceName] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
CREATE NONCLUSTERED INDEX [IDX_QueryHash_PlanHash_SqlHandle] ON [dbo].[QueryStats] 
(
	[QueryHash] ASC,
	[PlanHash] ASC,
	[SqlHandle] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[QueryPlans]    Script Date: 04/10/2016 12:16:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[QueryPlans](
	[PlanHash] [binary](8) NOT NULL,
	[SQLInstanceName] [varchar](200) NULL,
	[QueryPlan] [xml] NULL,
	[PlanCreationTime] [datetime] NULL,
	[CollectionDateTime] [datetime] NULL
	 CONSTRAINT [PK_QueryPlans] PRIMARY KEY CLUSTERED 
(
	[PlanHash] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
CREATE PRIMARY XML INDEX [PXML_QueryPlans] ON [dbo].[QueryPlans] 
(
	[QueryPlan]
)WITH (PAD_INDEX  = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
ALTER INDEX [PXML_QueryPlans] ON [dbo].[QueryPlans] DISABLE
GO
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
CREATE XML INDEX [IXML_QueryPlans_Path] ON [dbo].[QueryPlans] 
(
	[QueryPlan]
)
USING XML INDEX [PXML_QueryPlans] FOR PATH WITH (PAD_INDEX  = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
ALTER INDEX [IXML_QueryPlans_Path] ON [dbo].[QueryPlans] DISABLE
GO
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
CREATE XML INDEX [IXML_QueryPlans_Value] ON [dbo].[QueryPlans] 
(
	[QueryPlan]
)
USING XML INDEX [PXML_QueryPlans] FOR VALUE WITH (PAD_INDEX  = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)
ALTER INDEX [IXML_QueryPlans_Value] ON [dbo].[QueryPlans] DISABLE
GO

/****** Object:  Default [DF__WaitStati__DateI__2B3F6F97]    Script Date: 04/10/2016 12:16:39 ******/
ALTER TABLE [dbo].[WaitStatistics] ADD  DEFAULT (getdate()) FOR [CollectionDateTime]
GO

/****** Object:  Default [DF_ProcStats_CollectionDateTime]    Script Date: 04/10/2016 12:16:39 ******/
ALTER TABLE [dbo].[ProcStats] ADD  CONSTRAINT [DF_ProcStats_CollectionDateTime]  DEFAULT (getdate()) FOR [CollectionDateTime]
GO

/****** Object:  Default [DF_QueryStats_CollectionDateTime]    Script Date: 04/10/2016 12:16:39 ******/
ALTER TABLE [dbo].[QueryStats] ADD  CONSTRAINT [DF_QueryStats_CollectionDateTime]  DEFAULT (getdate()) FOR [CollectionDateTime]
GO

/****** Object:  Default [DF_QueryPlans_DateInserted]    Script Date: 04/10/2016 12:16:39 ******/
ALTER TABLE [dbo].[QueryPlans] ADD  CONSTRAINT [DF_QueryPlans_DateInserted]  DEFAULT (getdate()) FOR [CollectionDateTime]
GO


/****** Object:  StoredProcedure [dbo].[PurgePerfData]    Script Date: 04/10/2016 12:16:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
PurgePerfData -  procedure for purging collection data
Author:Fikrat Azizov
Date:April, 2016 
*/
CREATE procedure [dbo].[PurgePerfData]
@MaxDays int
As
delete  FROM [PerfStats].[dbo].Procstats where collectiondatetime>DATEADD(DAY,-@MaxDays,GETDATE()) 
delete  FROM [PerfStats].[dbo].QueryPlans where collectiondatetime>DATEADD(DAY,-@MaxDays,GETDATE()) 
delete  FROM [PerfStats].[dbo].[QueryStats] where collectiondatetime>DATEADD(DAY,-@MaxDays,GETDATE()) 
delete FROM [PerfStats].[dbo].[WaitStatistics] where collectiondatetime>DATEADD(DAY,-@MaxDays,GETDATE()) 
GO
/****** Object:  StoredProcedure [dbo].[GetWaitStats]    Script Date: 04/10/2016 12:16:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
GetWaitStats - collect wait stats
Author:Fikrat Azizov
Date:April, 2016 
*/
CREATE procedure [dbo].[GetWaitStats]
@TopN int=25,
@MinPct int=1
As
-- Isolate top waits for server instance since last restart or statistics clear
;WITH WaitsCTE AS
(SELECT TOP (@TopN) wait_type, wait_time_ms / 1000. AS wait_time_s,
100. * wait_time_ms / SUM(wait_time_ms) OVER() AS pct
FROM sys.dm_os_wait_stats
WHERE wait_type NOT IN ('CLR_SEMAPHORE','LAZYWRITER_SLEEP','RESOURCE_QUEUE','SLEEP_TASK'
,'SLEEP_SYSTEMTASK','SQLTRACE_BUFFER_FLUSH','WAITFOR', 'LOGMGR_QUEUE','CHECKPOINT_QUEUE'
,'REQUEST_FOR_DEADLOCK_SEARCH','XE_TIMER_EVENT','BROKER_TO_FLUSH','BROKER_TASK_STOP','CLR_MANUAL_EVENT'
,'CLR_AUTO_EVENT','DISPATCHER_QUEUE_SEMAPHORE', 'FT_IFTS_SCHEDULER_IDLE_WAIT'
,'XE_DISPATCHER_WAIT', 'XE_DISPATCHER_JOIN', 'SQLTRACE_INCREMENTAL_FLUSH_SLEEP'
,'DBMIRROR_EVENTS_QUEUE','DBMIRRORING_CMD','BROKER_RECEIVE_WAITFOR','BROKER_EVENTHANDLER'
,'ONDEMAND_TASK_QUEUE') ORDER BY pct desc)
Insert Into WaitStatistics ([SQLInstanceName],[Wait_type],[wait_time_s],[Pct])
	SELECT @@ServerName,wait_type,CAST(wait_time_s AS DECIMAL(12, 2)) AS wait_time_s,
	CAST(pct AS DECIMAL(6, 2)) AS pct FROM WaitsCTE  Where pct>@MinPct
GO

/****** Object:  View [dbo].[vQueryStats_Plans]    Script Date: 04/10/2016 12:16:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[vQueryStats_Plans]
AS
SELECT     QS.Id, QS.SQLInstanceName, QS.HostName, QS.DbName, REPLACE(REPLACE(REPLACE(QS.ParentQueryTxt, '	', '  '), CHAR(13), '  '), CHAR(10), ' ') AS ParentQueryTxt, 
                      REPLACE(REPLACE(REPLACE(QS.QueryTxt, '	', ' '), CHAR(13), ' '), CHAR(10), ' ') AS QueryTxt, QS.TotalElapsedTime_Msec, QS.MaxElapsedTime_Msec, 
                      QS.MinElapsedTime_Msec, QS.TotalElapsedTime_Msec / QS.ExecutionCount AS Avg_elapsedTime_MSec, QS.TotalWorkerTime_Msec, QS.MaxWorkerTime_Msec, 
                      QS.MinWorkerTime_Msec, QS.TotalWorkerTime_Msec / QS.ExecutionCount AS Avg_WorkerTime_MSec, QS.TotalLogicalReads, QS.MaxLogicalReads, 
                      QS.MinLogicalReads, QS.TotalLogicalReads / QS.ExecutionCount AS Avg_Logical_Reads, QS.ExecutionCount, QS.DateModified, QS.CollectionDateTime, 
                      QP.QueryPlan, QP.PlanCreationTime, QS.SqlHandle,  CONVERT(varchar(100), QS.QueryHash, 1) AS QueryHash, CONVERT(varchar(100), QS.PlanHash, 1) AS PlanHash
FROM         dbo.QueryStats AS QS LEFT OUTER JOIN
                      dbo.QueryPlans AS QP ON QS.SQLInstanceName = QP.SQLInstanceName AND QS.PlanHash = QP.PlanHash
GO

/****** Object:  View [dbo].[vProcStats_Plans]    Script Date: 04/10/2016 12:16:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[vProcStats_Plans]
AS
SELECT     PS.Id, PS.SQLInstanceName, PS.HostName, PS.DbName, SUBSTRING(PS.QueryTxt, PATINDEX('%].%', PS.QueryTxt) + 2, CHARINDEX(']', PS.QueryTxt, 
                      PATINDEX('%].%', PS.QueryTxt) + 1) - PATINDEX('%].%', PS.QueryTxt)) AS ProcName, PS.TotalElapsedTime_Msec, PS.MaxElapsedTime_Msec, 
                      PS.MinElapsedTime_Msec, PS.TotalElapsedTime_Msec / PS.ExecutionCount AS Avg_elapsedTime_MSec, PS.TotalWorkerTime_Msec, PS.MaxWorkerTime_Msec, 
                      PS.MinWorkerTime_Msec, PS.TotalWorkerTime_Msec / PS.ExecutionCount AS Avg_WorkerTime_MSec, PS.TotalLogicalReads, PS.MaxLogicalReads, 
                      PS.MinLogicalReads, PS.TotalLogicalReads / PS.ExecutionCount AS Avg_Logical_Reads, PS.ExecutionCount, QP.QueryPlan, PS.DateModified, QP.PlanCreationTime, 
                      PS.CollectionDateTime, PS.QueryTxt, CONVERT(varchar(100), PS.PlanHash, 1) AS PlanHash
FROM         dbo.ProcStats AS PS LEFT OUTER JOIN
                      dbo.QueryPlans AS QP ON PS.SQLInstanceName = QP.SQLInstanceName AND PS.PlanHash = QP.PlanHash
GO

/****** Object:  StoredProcedure [dbo].[CollectQueryStats]    Script Date: 04/10/2016 12:16:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
GetCostlyQueriesFromCache - collect query and procedure execution stats from SQL cache
Author:Fikrat Azizov
Date:April, 2016 
*/
Create procedure [dbo].[CollectQueryStats]
@vTopNRows int,
@vDbList varchar(200),
@vOrderBy varchar(200) ='TotalElapsedTime_MSec',
/*
List of fied names which can be included in @vOrderBy parameter:
	TotalWorkerTime_MSec,TotalElapsedTime_MSec,Total_logical_reads,MaxElapsedTime_MSec,MaxWorkerTime_MSec
	,max_logical_reads,	MinElapsedTime_MSec,MinWorkerTime_MSec,min_logical_reads,execution_count
*/
@vFilterStr varchar(max) =NULL,
/*
List of fied names which can be included in @vFilterStr parameter:
	total_worker_time,total_elapsed_time,Total_logical_reads,max_elapsed_time,max_worker_time
	,max_logical_reads,	min_elapsed_time,min_worker_time,min_logical_reads,execution_count
*/
@vCollectStatsInfo bit=0
AS
IF exists (Select 1 FROM tempdb.sys.objects where name='##QueriesFrmCache')
 drop table  ##QueriesFrmCache
IF  @vCollectStatsInfo=1 
 IF   Convert(int,Left(CONVERT(sysname, SERVERPROPERTY ('ProductVersion')),2))>=11
 BEGIN
   DBCC TRACEON(8666)
 END 
Declare @SqlStr varchar(max)=N'
SELECT TOP ('+LTRIM(STR(@vTopNRows))+') 
 @@SERVERNAME AS SQLInstanceName, 
 DB_Name(QP.dbid) As DBName,
 ST.text AS ParentQueryTxt, 
 SUBSTRING(ST.[text],QS.statement_start_offset/2+1, 
	(CASE 
		WHEN QS.statement_end_offset = -1 
	 THEN LEN(CONVERT(nvarchar(max), ST.[text])) * 2 
		ELSE QS.statement_end_offset 
	 END - QS.statement_start_offset)/2) AS [QueryTxt],
 QS.total_worker_time/1000 As TotalWorkerTime_MSec, 
 QS.total_elapsed_time/1000 As TotalElapsedTime_MSec, 
 QS.Total_logical_reads,
 QS.max_elapsed_time/1000 As MaxElapsedTime_MSec, 
 QS.max_worker_time/1000 As MaxWorkerTime_MSec, 
 QS.max_logical_reads,
 QS.min_elapsed_time/1000 As MinElapsedTime_MSec, 
 QS.min_worker_time/1000 As MinWorkerTime_MSec, 
 QS.min_logical_reads,
 QS.execution_count,
 QS.query_hash, 
 QS.sql_handle,
 QS.query_plan_hash,
 QP.query_plan,
 QS.Statement_start_offset,
 QS.creation_time 
 INTO ##QueriesFrmCache
 FROM sys.dm_exec_query_stats QS
 CROSS APPLY sys.dm_exec_sql_text(QS.sql_handle) AS ST 
 CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle) QP
 WHERE ' + CASE WHEN @vDbList IS NULL  THEN '1=1' ELSE 'DB_NAME(QP.dbid) IN ('''+@vDbList+''') ' END
 + ' AND ' +  COALESCE(@vFilterStr,'1=1')+ ' ORDER BY ' +@vOrderBy + '  DESC' 
exec (@SqlStr)
MERGE  QueryStats QS
 USING ##QueriesFrmCache QSC 
 ON QS.queryhash =QSC.query_hash AND  QS.planhash =QSC.query_plan_hash
  and QS.sqlhandle=QSC.sql_handle AND QS.Statement_start_offset=QSC.Statement_start_offset
  AND QS.SQLInstanceName=QSC.SQLInstanceName
WHEN MATCHED THEN
 UPDATE Set QS.TotalWorkerTime_MSec=QSC.TotalWorkerTime_MSec,
	QS.TotalElapsedTime_Msec=QSC.TotalElapsedTime_Msec,
	QS.TotalLogicalReads=QSC.Total_logical_reads,
	QS.ExecutionCount=QSC.execution_count,
	QS.MaxElapsedTime_MSec =(CASE WHEN QS.MaxElapsedTime_MSec>=QSC.MaxElapsedTime_MSec 
		THEN QS.MaxElapsedTime_MSec ELSE QSC.MaxElapsedTime_MSec END),
	QS.MaxWorkerTime_MSec =(CASE WHEN QS.MaxWorkerTime_MSec>=QSC.MaxWorkerTime_MSec 
		THEN QS.MaxWorkerTime_MSec ELSE QSC.MaxWorkerTime_MSec END),
	QS.MaxLogicalReads =(CASE WHEN QS.MaxLogicalReads>=QSC.max_logical_reads 
		THEN QS.MaxLogicalReads ELSE QSC.max_logical_reads END),
	QS.MinElapsedTime_MSec =(CASE WHEN QS.MinElapsedTime_MSec>=QSC.MinElapsedTime_MSec 
		THEN QS.MinElapsedTime_MSec ELSE QSC.MinElapsedTime_MSec END),
	QS.MinWorkerTime_MSec =(CASE WHEN QS.MinWorkerTime_MSec>=QSC.MinWorkerTime_MSec 
		THEN QS.MinWorkerTime_MSec ELSE QSC.MinWorkerTime_MSec END),
	QS.MinLogicalReads =(CASE WHEN QS.MinLogicalReads>=QSC.min_logical_reads 
		THEN QS.MinLogicalReads ELSE QSC.min_logical_reads END),
	QS.DateModified=GetDate()
WHEN NOT MATCHED BY TARGET THEN
INSERT   ([SQLInstanceName]  ,HostName,[DbName] ,[ParentQueryTxt] ,[QueryTxt],[TotalWorkerTime_MSec]
    ,[TotalElapsedTime_MSec],[TotalLogicalReads] ,[MaxElapsedTime_MSec] ,[MaxWorkerTime_MSec] 
	,[MaxLogicalReads] ,[MinElapsedTime_MSec],[MinWorkerTime_MSec] ,[MinLogicalReads] ,[ExecutionCount] 
	,[QueryHash] ,[SqlHandle] ,[PlanHash],[Statement_start_offset])
VALUES (QSC.[SQLInstanceName] ,CAST(SERVERPROPERTY ('ComputerNamePhysicalNetBIOS') AS Varchar(100))
	,QSC.[DbName] ,QSC.[ParentQueryTxt],QSC.[QueryTxt] ,QSC.[TotalWorkerTime_Msec]
	,QSC.[TotalElapsedTime_Msec] ,QSC.Total_logical_reads ,QSC.[MaxElapsedTime_Msec] 
	,QSC.[MaxWorkerTime_Msec],QSC.max_logical_reads ,QSC.[MinElapsedTime_msec]
	,QSC.[MinWorkerTime_msec],QSC.min_logical_reads,QSC.execution_count,QSC.[Query_Hash]
	,QSC.[Sql_Handle],QSC.query_plan_hash,QSC.[Statement_start_offset]);

INSERT INTO dbo.QueryPlans (SQLInstanceName,PlanHash)
 SELECT DISTINCT @@SERVERNAME,QC.query_plan_hash FROM ##QueriesFrmCache QC 
  LEFT JOIN QueryPlans QP ON QC.query_plan_hash=QP.PlanHash
  WHERE QP.PlanHash IS NULL AND QC.Query_Plan IS NOT NULL
UPDATE QP SET QP.PlanCreationTime=QC.creation_time,QP.QueryPlan=QC.Query_Plan 
  FROM dbo.QueryPlans QP JOIN ##QueriesFrmCache QC ON QC.query_plan_hash=QP.PlanHash 
  AND QP.SQLInstanceName=QC.SQLInstanceName

--Collect procedure stats
IF exists (Select 1 FROM tempdb.sys.objects where name='##ProcsFrmCache')
  drop table  ##ProcsFrmCache
SET @SqlStr =N'SELECT TOP ('+LTRIM(STR(@vTopNRows))+') 
 @@SERVERNAME AS SQLInstanceName, 
 DB_Name(ST.dbid) As DBName,
 ST.text AS [QueryTxt],
 PS.total_worker_time/1000 As TotalWorkerTime_MSec, 
 PS.total_elapsed_time/1000 As TotalElapsedTime_MSec, 
 PS.Total_logical_reads,
 PS.max_elapsed_time/1000 As MaxElapsedTime_MSec, 
 PS.max_worker_time/1000 As MaxWorkerTime_MSec, 
 PS.max_logical_reads,
 PS.min_elapsed_time/1000 As MinElapsedTime_MSec, 
 PS.min_worker_time/1000 As MinWorkerTime_MSec, 
 PS.min_logical_reads,
 PS.execution_count,
 PS.sql_handle,
 PH.query_plan_hash,
 QP.query_plan,
 PS.cached_time 
 INTO ##ProcsFrmCache
 FROM sys.dm_exec_procedure_stats PS
 CROSS APPLY (Select TOP 1 query_plan_hash FROM ##QueriesFrmCache WHERE Sql_Handle=PS.Sql_handle) PH
 CROSS APPLY sys.dm_exec_sql_text(PS.sql_handle) AS ST 
 CROSS APPLY sys.dm_exec_query_plan(PS.plan_handle) QP
 WHERE ' + CASE WHEN @vDbList IS NULL  THEN '1=1' ELSE 'DB_NAME(QP.dbid) IN ('''+@vDbList+''') ' END
 + ' AND ' +  COALESCE(@vFilterStr,'1=1')+ ' ORDER BY ' +@vOrderBy + '  DESC' 
exec (@SqlStr)
MERGE  ProcStats QS
 USING ##ProcsFrmCache QSC 
 ON  QS.sqlhandle=QSC.sql_handle AND QS.PlanHash=QSC.query_plan_hash
 AND QS.SQLInstanceName=QSC.SQLInstanceName
WHEN MATCHED THEN
 UPDATE Set QS.TotalWorkerTime_MSec=QSC.TotalWorkerTime_MSec,
	QS.TotalElapsedTime_Msec=QSC.TotalElapsedTime_MSec,
	QS.TotalLogicalReads=QSC.Total_Logical_Reads,
	QS.ExecutionCount=QSC.Execution_Count,
	QS.MaxElapsedTime_MSec=(CASE WHEN QS.MaxElapsedTime_msec>=QSC.MaxElapsedTime_MSec
		THEN QS.MaxElapsedTime_MSec ELSE QSC.MaxElapsedTime_MSec END),
	QS.MaxWorkerTime_MSec=(CASE WHEN QS.MaxWorkerTime_msec>=QSC.MaxWorkerTime_MSec 
		THEN QS.MaxWorkerTime_MSec ELSE QSC.MaxWorkerTime_MSec END),
	QS.MaxLogicalReads =(CASE WHEN QS.MaxLogicalReads>=QSC.Max_Logical_Reads 
		THEN QS.MaxLogicalReads ELSE QSC.Max_Logical_Reads END),
	QS.MinElapsedTime_MSec =(CASE WHEN QS.MinElapsedTime_msec>=QSC.MinElapsedTime_MSec 
		THEN QS.MinElapsedTime_MSec ELSE QSC.MinElapsedTime_MSec END),
	QS.MinWorkerTime_MSec =(CASE WHEN QS.MinWorkerTime_msec>=QSC.MinWorkerTime_MSec 
		THEN QS.MinWorkerTime_MSec ELSE QSC.MinWorkerTime_MSec END),
	QS.MinLogicalReads =(CASE WHEN QS.MinLogicalReads>=QSC.Min_Logical_Reads 
		THEN QS.MinLogicalReads ELSE QSC.Min_Logical_Reads END),
	QS.DateModified=GetDate()
WHEN NOT MATCHED BY TARGET THEN
INSERT   ([SQLInstanceName]  ,HostName,[DbName] ,[QueryTxt],[TotalWorkerTime_msec] ,[TotalElapsedTime_msec]
	,[TotalLogicalReads] ,[MaxElapsedTime_msec] ,[MaxWorkerTime_MSec] ,[MaxLogicalReads] ,[MinElapsedTime_msec]
	,[MinWorkerTime_msec] ,[MinLogicalReads] ,[ExecutionCount] ,[SqlHandle] ,[PlanHash])
VALUES (QSC.[SQLInstanceName] ,HOST_NAME(),	QSC.[DbName] ,QSC.[QueryTxt] ,QSC.[TotalWorkerTime_Msec]
	,QSC.[TotalElapsedTime_Msec] ,QSC.[Total_Logical_Reads] ,QSC.[MaxElapsedTime_MSec] ,QSC.[MaxWorkerTime_Msec]
	,QSC.[Max_Logical_Reads] ,QSC.[MinElapsedTime_Msec],QSC.[MinWorkerTime_Msec] ,QSC.[Min_Logical_Reads]           
	,QSC.[Execution_Count],QSC.[Sql_Handle],QSC.query_plan_hash);
IF  @vCollectStatsInfo=1 
 IF   Convert(int,Left(CONVERT(sysname, SERVERPROPERTY ('ProductVersion')),2))>=11
 BEGIN
  DBCC TRACEOFF(8666)
 END 
 GO
/****** Object:  StoredProcedure [dbo].[CollectPerfStats]    Script Date: 04/10/2016 12:16:39 ******/

/*
CollectPerfStats - shell procedure to trigger performance collection procedures 
Author:Fikrat Azizov
Date:April, 2016 
*/
CREATE PROCEDURE [dbo].[CollectPerfStats]
@DbList varchar(200),
@GetQueryStats bit=1,
@TopN int,
@OrderBy varchar(200) ='TotalElapsedTime_MSec',
@FilterStr varchar(max) =NULL,
@CollectStatsInfo bit=0,
@GetWaitStats bit=0
AS
IF @GetQueryStats=1 exec [CollectQueryStats] @vTopNRows=@TopN,@vDbList=@DbList,@vOrderBy=@OrderBy,@vFilterStr=@FilterStr,@vCollectStatsInfo=@CollectStatsInfo;
IF @GetWaitStats=1 exec GetWaitStats 10,5;
GO
/****** Object:  StoredProcedure [dbo].[GetIndexFragmentationStats]    Script Date: 04/10/2016 12:16:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
